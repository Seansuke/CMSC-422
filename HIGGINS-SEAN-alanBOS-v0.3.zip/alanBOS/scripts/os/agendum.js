/* ------------  
   agendum.js
   Our CPU Scheduler
   It's like Moneypenny, but without the flirting.  I'll change that.
   ------------ */
   
// I'll be scheduling your tasks, Mr. Bond.
// "Please, call me James"
function Agendum() {
	// Variables
	this.jobs = new Array(); // Simulates our Ready Queue
	this.timer = -1;
	this.currentJob = -1;
	
	// Methods
	this.jobDone = AgendumJobDone; // Callback function
	this.newJob = AgendumNewJob; // Callback function
	this.cycle = AgendumCycle; // Callback function
	this.empty = AgendumEmpty; // Callback function
	this.log = AgendumLog; // Callback function
	this.log();
}

// There's a new assignment James, do be careful.
function AgendumNewJob( pcbId ) {
	this.jobs.push( pcbId );
	krnTrace("Added. PID:" + this.jobs[ this.jobs.length - 1 ] + ", Job ID:" + (this.jobs.length - 1) );
	this.log();
}

// Show all the information to the areatext  Debug purposes only
function AgendumLog() {
	var output = "CPU SCHEDULER\n";
	output += "Current Job: " + this.currentJob + "\n";
	output += "Timer: " + this.timer + "\n";
	output += "PIDs: ";
	for(var i = 0; i < this.jobs.length; i += 1) {
		output += this.jobs[i] + ",";
	}
	output = output.substring( 0, output.length - 1 );
	document.getElementById("agendumLog").value = output;
}

// Job well done, James.  I'll notify M that your mission is completed.
function AgendumJobDone() {
	krnTrace("Terminating. PID:" + this.jobs[this.currentJob] + ", Job ID:" + this.currentJob);
	this.jobs.splice(this.currentJob, 1);
	this.currentJob -= 1;
	this.timer = -1;
	this.log();
}

// Clear the Agenda
function AgendumEmpty() {
	while( this.jobs.length > 0) { 
		this.jobs.pop();
		this.timer = -1;
		this.currentJob = -1;	
	}
	this.log();
}

// Please don't interrupt my job, James!
function AgendumCycle() {	
	// A break now.  Care for a drink?
	if( this.jobs.length == 0 ) {
		this.log();
		return -1;
	}
	
	// News flash James!  We need you to stop what you're doing to work on a different mission!
	if( this.timer <= 0 ) {
		this.currentJob = (this.currentJob + 1) % this.jobs.length;
		this.timer = QUANTUM;
		krnTrace("Setting Current Job. PID:" + this.jobs[this.currentJob] + ", Job ID:" + this.currentJob);
	}
	
	// Status is ok, James.  Continue with your mission.
	krnTrace("Running. PID:" + this.jobs[this.currentJob] + ", Job ID:" + this.currentJob);
	this.timer -= 1;
	
	this.log();
	
	// return the PID James is working on
	return this.jobs[this.currentJob];
}