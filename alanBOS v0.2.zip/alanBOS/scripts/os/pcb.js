/* ----------------------------------
   pcb.js
   
   The Process Control Block.
   ---------------------------------- */

function pcb() {
	// The actual process control array with it's index as the process ID
    this.pcb = new Array(); 
	
	// The real quantity of living processes.
	this.size = 0;
	
	// Init the array with emptiness
	for( i = 0; i < 5; i += 1 ) {
		this.pcb[i] = new pcbProcess();
	}
	
	this.add = pcbAdd; // Function Callback
	this.display = pcbDisplay; // Function Callback
	this.kill = pcbKill; // Function Callback
	this.run = pcbRun; // Function callback
}

// Memory: "OOOO PROGRAM STRING!  OMNOMNOMNOM! (^o^)"
// Me: "Hold up, Pacman! (O_O) "
function pcbAdd( prog ) {
	// Find a free pcb index
	var index = 0;
	for(index = 0; this.pcb[index].limit != 0 && index < 4; index += 1) {
		// Cycle through until a free index is found
	}
	// Our PCB is limited to 4 processes.  Why?  So I can increase it later on XP
	if( index == 4 ) {
		// Well, we can't have more than 4, tell the world we failed.
		return -1;
	}
	var base = 0;
	// If there are processes in memory already, we need to optimize where we put the program.
	if(this.size != 0) {
		// Find the optimal free space to dump the program
		var limit = prog.length;
		// Check every process 
		base = -1;
		for(var i = 0; base == -1 && i < 4; i += 1) {
			// Innocent until proven guilty
			base = this.pcb[i].base + this.pcb[i].limit;
			// If we selected a candidate, make sure it is far enough away from the end of memory, or else don't even bother checking
			if( this.pcb[i].base + this.pcb[i].limit + prog.length < TOTAL_MEMORY ) {
				// Check it against every single other process
				for(var j = 0 ; j < 4 ; j += 1) {
					// Check against everyone but yourself, check non-empty processes, check if shorter
					if( i != j && this.pcb[j].limit != 0 && this.pcb[i].base < this.pcb[j].base ) {
						// Is the gap between these two process too small?
						if( this.pcb[i].base + this.pcb[i].limit + prog.length > this.pcb[j].base ) {
							// Then we rule out this base entirely
							base = -1;
							j = 4; // Quit subloop escape
						}
					}
				}
			}
			else {
				base = -1;
			}
		}
		// Our loop must have failed, let's just tell the world of this shame.
		if( base == -1 ) {
			return -1;
		}
	}
	// Now we can FINALLY assign the program.
	var i = index;
	this.pcb[i] = new pcbProcess();
	this.pcb[i].limit = prog.length;
	this.pcb[i].base = base;
	var address = this.pcb[i].base;
	// Dump it in until the string is essentially empty
	while( prog.length > 1 ) { 
		// Take a bite of a Byte
		var programByte = prog.substring(0,2);
		// If the text is a single character...
		if (prog.length == 3) {
			// Just make text be an empty string.  This will prevent .length causing an exception
			prog = "";
		}
		else {
			// Truncate the first 2 hex.
			prog = prog.substring(3);
		}
		// Chomp
		RAM[ address ] = programByte;
		address += 1;
	}
	_CPU.displayMemory(); // For debug purposes.
	this.size += 1;
	return i;
}

function pcbRun( id ) {
	_CPU.PC = this.pcb[id].base;
	_CPU.base = this.pcb[id].base;
	_CPU.isExecuting = true;
}

// A single node containing a process's information
function pcbProcess() {
    this.Zflag = 0;     // Z-ero flag (Think of it as "isZero".)	
    this.PC    = 0;     // Program Counter
    this.Acc   = 0;     // Accumulator
    this.Xreg  = 0;     // X register
    this.Yreg  = 0;     // Y register
	this.base  = 0;     // the base memory location
	this.limit = 0;		// the memory limit
}

// Return the information for each process as a string that could be output to the console.
function pcbDisplay() {
	var output = "";
	for(i = 0; i < 4; i += 1) {
		if( this.pcb[i].limit != 0 ) {
			output += "({id:" + i + ", base:" + this.pcb[i].base + ", limit:" + this.pcb[i].limit + "})\n";
		}
	}
	return output;
}

function pcbKill( args ) {
	if( this.pcb[args].limit != 0 ) {
		// Return the process in memory completely to 0s
		for(var i = this.pcb[args].base ; i < this.pcb[args].base + this.pcb[args].limit ; i += 1) {
			RAM[i] = "00";
		}
		// Return the pcb object back to default
		this.pcb[args] = new pcbProcess();
		this.size -= 1;
		return "Process " + args + " Killed";
	}
	else {
		return "Process does not exist";
	}
}