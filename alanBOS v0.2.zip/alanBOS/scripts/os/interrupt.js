/* ------------
   Interrupt.js   
   ------------ */
   
function Interrput(_irq, _params)
{
    // Properties
    this.irq = _irq;
    this.params = _params;
}
