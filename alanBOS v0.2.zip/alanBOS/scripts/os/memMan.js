/* ------------  
   MemMan.js
   ------------ */
function memMan() {
	// Variables
	
	
	// Methods
	this.setByte = memSetByte; // Callback function
	this.getByte = memGetByte; // Callback function
	this.addByte = memAddByte; // Callback function
}
function memSetByte( hexAddress , hexValue ) {
	var decAddress = parseInt( hexAddress , 16 );
	RAM[ decAddress ] = hexValue;
}
function memGetByte( hexAddress ) {
	var decAddress = parseInt( hexAddress , 16 );
	return RAM[ decAddress ];
}
function memAddByte( hexAddress , amnt ) {
	var decAddress = parseInt( hexAddress , 16 );
	var decValue = parseInt( RAM[ decAddress ] , 16 );
	decValue += parseInt( amnt , 16 );
	var hexValue = ( decValue ).toString(16);
	return hexValue;
}
